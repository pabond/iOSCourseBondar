//
//  BPVRemoveModel+BPVArrayModel.h
//  iOSProject
//
//  Created by Bondar Pavel on 8/15/16.
//  Copyright © 2016 Pavel Bondar. All rights reserved.
//


#import "BPVArrayModel.h"
#import "BPVRemoveModel.h"

@interface BPVRemoveModel (BPVArrayModel)

@end
