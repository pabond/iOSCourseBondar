//
//  BPVArrayChange+BPVArrayModel.m
//  iOSProject
//
//  Created by Bondar Pavel on 8/16/16.
//  Copyright © 2016 Pavel Bondar. All rights reserved.
//

#import "BPVArrayChange+BPVArrayModel.h"

@implementation BPVArrayChange (BPVArrayModel)

- (void)applyToModel:(id)model withObject:(id)object {

}

@end
