//
//  UINib+BPVExtensions.m
//  iOSProject
//
//  Created by Bondar Pavel on 8/11/16.
//  Copyright © 2016 Pavel Bondar. All rights reserved.
//

#import "UINib+BPVExtensions.h"

#import "NSArray+BPVExtensions.h"

@implementation UINib (BPVExtensions)

+ (id)objectWithClass:(Class)class {
    UINib *nib = [self nibWithClass:class];
    
    return [nib objectWithClass:class];
}

+ (instancetype)nibWithClass:(Class)class {
    return [self nibWithClass:class bundle:nil];
}

+ (instancetype)nibWithClass:(Class)class bundle:(NSBundle *)bundle {
    return [self nibWithNibName:NSStringFromClass(class) bundle:bundle];
}

- (id)objectWithClass:(Class)class {
    return [self objectWithClass:(Class)class owner:nil options:nil];
}

- (id)objectWithClass:(Class)class owner:(id)owner options:(NSDictionary *)options {
    return [[self instantiateWithOwner:owner options:options] objectWithClass:class];
}

@end
