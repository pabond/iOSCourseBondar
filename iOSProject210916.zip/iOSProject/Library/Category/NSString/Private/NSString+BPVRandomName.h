//
//  NSString+BPVRandomName.h
//  iOSProject
//
//  Created by Bondar Pavel on 7/30/16.
//  Copyright © 2016 Pavel Bondar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (BPVRandomName)

+ (instancetype)randomName;

@end
