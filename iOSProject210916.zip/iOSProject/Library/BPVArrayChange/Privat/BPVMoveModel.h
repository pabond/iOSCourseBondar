//
//  BPVMoveModel.h
//  iOSProject
//
//  Created by Bondar Pavel on 8/14/16.
//  Copyright © 2016 Pavel Bondar. All rights reserved.
//

#import "BPVTwoIndexArrayChange.h"

@interface BPVMoveModel : BPVTwoIndexArrayChange

@end
