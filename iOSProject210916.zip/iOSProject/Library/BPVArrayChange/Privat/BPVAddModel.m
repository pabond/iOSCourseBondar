//
//  BPVAddModel.m
//  iOSProject
//
//  Created by Bondar Pavel on 8/12/16.
//  Copyright © 2016 Pavel Bondar. All rights reserved.
//

#import "BPVAddModel.h"

#import "BPVFilteredModel.h"

@implementation BPVAddModel

@end
