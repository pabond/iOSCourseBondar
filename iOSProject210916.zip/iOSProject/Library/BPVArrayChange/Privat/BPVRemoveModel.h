//
//  BPVRemoveModel.h
//  iOSProject
//
//  Created by Bondar Pavel on 8/12/16.
//  Copyright © 2016 Pavel Bondar. All rights reserved.
//

#import "BPVOneIndexArrayChange.h"

@interface BPVRemoveModel : BPVOneIndexArrayChange

@end
