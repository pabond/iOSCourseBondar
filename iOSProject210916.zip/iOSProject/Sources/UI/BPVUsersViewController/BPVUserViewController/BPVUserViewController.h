//
//  BPVUserViewController.h
//  iOSProject
//
//  Created by Bondar Pavel on 9/20/16.
//  Copyright © 2016 Pavel Bondar. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BPVUser;

@interface BPVUserViewController : UIViewController
@property (nonatomic, strong) BPVUser *user;

@end
